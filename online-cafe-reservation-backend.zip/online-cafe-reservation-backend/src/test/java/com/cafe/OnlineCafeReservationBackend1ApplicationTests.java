package com.cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCafeReservationBackend1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
