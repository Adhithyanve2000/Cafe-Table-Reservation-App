package com.cafe.exception;

public class ItemCreationException extends RuntimeException {

    public ItemCreationException(String message) {
        super(message);
    }
}
