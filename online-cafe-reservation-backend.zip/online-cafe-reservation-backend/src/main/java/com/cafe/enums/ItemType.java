package com.cafe.enums;

public enum ItemType {
    DESSERT, LUNCH, BREAK_FAST, DINNER
}
