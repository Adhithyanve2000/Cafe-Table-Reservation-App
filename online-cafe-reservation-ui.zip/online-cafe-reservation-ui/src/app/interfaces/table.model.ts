export interface Table {
    id?: number
    tableName?: string
    tableType?: string 
    tableStatus?: string 
}
