export interface AddMenu {
    itemName: string;
    description: string;
    price: number;
    availability: boolean;
    type: string;
}
