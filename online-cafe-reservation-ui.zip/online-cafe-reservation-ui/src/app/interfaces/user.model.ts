export interface User {
    // user.model.ts
    userId?:number
    userName?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    gender?: string;
    password?: string;
    role?: string;  
}
