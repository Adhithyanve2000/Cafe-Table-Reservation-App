import { Component, OnInit } from '@angular/core';
import { MenuService } from 'src/app/services/menu.service';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css']
})
export class MenuListComponent implements OnInit {

  constructor(private ms: MenuService) { }

  menus: any;
  backUpMenus: any;
  notFoundMssg: any;
  buttonLabels: string[] = ['Show All', 'Breakfast', 'Lunch', 'Dinner', 'Desert'];
  selectedButtonIndex: number | null = 0;
  selectButton(index: number): void {
    this.selectedButtonIndex = index;
    let tabType: string = 'all';  
    switch (index) {
      case 1:
        tabType = 'BREAK_FAST';
        break;
      case 2:
        tabType = 'lunch';
        break;
      case 3:
        tabType = 'dinner';
        break;
      case 4:
        tabType = 'dessert';
        break;
      default:
        break; 
    }
  
    if (tabType !== "all") {
      this.ms.getMenusByType(tabType).subscribe((data: any) => {

        this.menus = data.items.filter((item: any) => item.enable);
        console.log('Menu items for tab type:', tabType, data);
        if (this.menus.length < 1) {
          this.notFoundMssg = "Oops! Items Not Found ";
        } else {
          this.notFoundMssg = "";
        }
      });
    } else {
      this.menus = this.backUpMenus;
    }
  }

  ngOnInit(): void {
    this.fngetAllMenus();
  }

  fngetAllMenus() {
    this.ms.getAllMenu().subscribe(
      (data: any) => {
        console.log(data);
        this.backUpMenus = data?.items;
        this.menus = this.backUpMenus.filter((item: any) => item.enable);
      }, (error) => {
        console.log(error);
      }
    );
  }
}
