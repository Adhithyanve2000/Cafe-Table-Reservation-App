import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-side-navbar',
  templateUrl: './user-side-navbar.component.html',
  styleUrls: ['./user-side-navbar.component.css']
})
export class UserSideNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
